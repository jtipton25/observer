log_sum_exp <- function(u, v) {
  maxuv <- pmax(u, v)
  return(maxuv + log(exp(u - maxuv) + exp(v - maxuv)))
}

## log_sum_exp(log(3), log(3))
## log(3 + 6)