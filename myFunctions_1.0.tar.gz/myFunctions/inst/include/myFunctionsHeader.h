// log 2 pi
const double log2pi = std::log(2.0 * M_PI);

// ARMA b-spline construction
// sequence function for 
Rcpp::NumericVector seq_lenBS(const int& n) {
  if (n < 2) {
    Rcpp::stop("Inadmissible value");
  }
  Rcpp::NumericVector out(n);
  out(0) = 0.0;
  out(n-1) = 1.0;
  if (n > 2) {
    double n_double = double(n-1);
    for (int i=1; i<(n-1); i++) {
      double j = double(i);
      out(i) = j / n_double;
    }
  }
  
  return(out);
}

Rcpp::NumericVector quantileBS(const Rcpp::NumericVector& x,
                               const Rcpp::NumericVector& probs) {
  Rcpp::Environment stats("package:stats");
  Rcpp::Function quantile = stats["quantile"];
  int npr = probs.size();
  Rcpp::NumericVector ans(npr);
  for(int i=0; i<npr; i++){
    ans[i] = Rcpp::as<double>(quantile(x, probs[i]));
  }
  return(ans);
}

double basis_cpp (const double& x, const int& degree, const int& i, 
                  const arma::vec& knots) {
  double B;
  double alpha1;
  double alpha2;
  if (degree == 0) {
    if ((x >= knots(i)) && (x < knots(i+1))) {
      B = 1.0;
    } else {
      B = 0.0;
    }
  } else {
    if((knots(degree+i) - knots(i)) == 0.0) {
      alpha1 = 0.0;
    } else {
      alpha1 = (x - knots(i))/(knots(degree+i) - knots(i));
    }
    if((knots(i+degree+1) - knots(i+1)) == 0.0) {
      alpha2 = 0.0;
    } else {
      alpha2 = (knots(i+degree+1) - x)/(knots(i+degree+1) - knots(i+1));
    }
    B = alpha1*basis_cpp(x, (degree-1), i, knots) + 
      alpha2*basis_cpp(x, (degree-1), (i+1), knots);
  }
  return(B);
}

// Arma basis function
arma::mat bs_cpp (const arma::vec& x, const int& df, 
                  const arma::vec& interior_knots, const int& degree, 
                  const bool& intercept, 
                  const arma::vec& Boundary_knots) {
  // arma::vec interior_knots = empty) {
  arma::vec Boundary_knots_sorted = sort(Boundary_knots);
  // arma::vec interior_knots_sorted = sort(interior_knots);
  arma::vec knots_lower(degree+1);
  knots_lower.fill(Boundary_knots_sorted(0));
  arma::vec knots_upper(degree+1);
  knots_upper.fill(Boundary_knots_sorted(1));
  // int n_interior_knots = df - degree - 1;
  // arma::vec interior_knots(n_interior_knots);
  // Rcpp::NumericVector probs = seq_lenBS(n_interior_knots + 2);
  // probs.erase(n_interior_knots + 1);
  // probs.erase(0);
  // Rcpp::NumericVector xNV(x.n_elem);
  // for (int i=0; i<x.n_elem; i++) {
  //   xNV(i) = x(i);
  // }
  // Rcpp::NumericVector knots_interiorNV = quantileBS(xNV, probs);
  // for (int i=0; i<n_interior_knots; i++) {
  //   interior_knots(i) = knots_interiorNV(i);
  // }
  arma::vec knots_tmp = arma::join_cols(knots_lower, interior_knots);
  arma::vec knots = arma::join_cols(knots_tmp, knots_upper);
  // arma::vec knots = join_cols(join_cols(knots_lower, interior_knots_sorted),
  //                             knots_upper);
  // int K = degree + 1;
  int K = interior_knots.n_elem + degree + 1;
  int nx = x.n_elem;
  arma::mat B_mat(nx, K, arma::fill::zeros);
  for (int i=0; i<nx; i++) {
    for (int j=0; j<K; j++) {
      B_mat(i, j) = basis_cpp(x(i), degree, j, knots);
    }
  }
  if(any(x == Boundary_knots_sorted(1))){
    arma::uvec idx = arma::find(x == Boundary_knots_sorted(1));
    int n_idx = idx.n_elem;
    arma::uvec K_uvec(n_idx);
    K_uvec.fill(K-1);
    arma::vec one_vec(n_idx, arma::fill::ones);
    B_mat.submat(idx, K_uvec) = one_vec;
  } 
  if(intercept == FALSE) {
    return(B_mat.cols(arma::span(1, K-1)));
  } else {
    return(B_mat);
  }
}

// ARMA version of cbind
arma::mat cbindARMA(const arma::mat & A, const arma::mat & B){
  int nrows = A.n_rows;		
	int ncolsA = A.n_cols;
	int ncolsB = B.n_cols;
	arma::mat out(nrows, ncolsA + ncolsB);
	for(int i = 0; i < ncolsA + ncolsB; i++){
		if(i < ncolsA){
			out.col(i) = A.col(i);
		} else {
			out.col(i) = B.col(i - ncolsA);
		}
	}
	return(out);
}

// ARMA version of colSums
arma::vec colSums(const arma::mat & X){
   int nCols = X.n_cols;
   arma::vec out(nCols);
   for(int i = 0; i < nCols; i++){
      out(i) = sum(X.col(i));
   }
   return(out);
}

// Convert mean, variance parametrization of Inverse Gamma distribution to shape
double convertToAlpha(const double & mu, const double & s2){
  return(pow(mu, 2) / s2 + 2.0);
}

// Convert mean, variance parametrization of Inverse Gamma distribution to scale 
double convertToBeta(const double & mu, const double & s2){
	return(mu * (pow(mu, 2) / s2 + 1.0));
}

// computes (log) denisty of Inverse Gamma distribution for a scalar value
double dinvgammaArma(const double & x, const double & shape, 
  										const double & rate, const bool logarithm = true){
  double logval = shape * log(rate) - lgamma(shape) - rate / x - (shape + 1.0) * log(x);
  if(logarithm){
    return(logval);
  } else {
    return(exp(logval));
  }
}

// computes (log) denisty of Inverse Gamma distribution for a vector value
arma::vec dinvgammaArmaVec(const arma::vec & x, const double & shape, const double & rate,
											const bool logarithm = true){
  int n = x.n_elem;
  arma::vec logval(n, arma::fill::zeros);
  for(int i = 0; i < n; i++){
  	logval(i) = shape * log(rate) - lgamma(shape) - rate / x(i) - (shape + 1.0) * log(x(i));
  }
  if(logarithm){
    return(logval);
  } else {
    return(exp(logval));
  }
}

//lognormal density
double dlnormARMA(const double& x, const double& mu, 
  										const double& s2, const bool logarithm = true){
  double logval = - 0.5 * (log2pi + log(s2)) - log(x) - 
                  0.5 / s2 * pow(log(x) - mu, 2);
  if(logarithm){
    return(logval);
  } else {
    return(exp(logval));
  }
}

// multivariate normal density


double dMVNorm(const arma::vec & y, const arma::vec & mu, 
                const arma::mat & Sig, const bool logd = true){ 
   arma::mat rooti = trans(inv(trimatu(chol(Sig))));
   double rootisum = sum(log(rooti.diag()));      
   double constants = -(y.n_elem / 2.0) * log2pi;
   arma::vec z = rooti * (y - mu) ;      
   double out = constants - 0.5 * sum(z % z) + rootisum;       
   if(logd){
     return(out);
   } else {
     return(exp(out));
   }
}

// Fast approximation to the normal inverse CDF
double phi(const double & x)
{
  // constants
  double a1 =  0.254829592;
  double a2 = -0.284496736;
  double a3 =  1.421413741;
  double a4 = -1.453152027;
  double a5 =  1.061405429;
  double p  =  0.3275911;
  
  // Save the sign of x
  int sign = 1;
  if (x < 0){
    sign = - 1;
  }
  double x_abs = fabs(x) / sqrt(2.0);
  
  // A&S formula 7.1.26
  double t = 1.0 / (1.0 + p * x_abs);
  double y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * 
    					t * exp(-x_abs * x_abs);
  
  return 0.5 * (1.0 + sign * y);
}

// Log determinant of positive symmetric matrix
double logDet(const arma::mat Sig) {
    arma::mat rooti = chol(Sig);
    return(2.0 * sum(log(rooti.diag())));
}

// Calculate Euclidean distance between two points
//arma::mat makeDistARMA(const arma::mat & coords1, const arma::mat & coords2){
//  int nrows1 = coords1.n_rows;
//  int nrows2 = coords2.n_rows;
//  arma::mat D(nrows1, nrows2, arma::fill::zeros);
//  for(int i = 0; i < nrows1; i++){
//    for(int j = 0; j < nrows2; j++){
//      double tmp = 0;
//      for(int k = 0; k < 2; k++){
//      tmp += pow(coords1(i, k) - coords2(j, k), 2);
//      }
//      D(i, j) = sqrt(tmp);
//    }
//  }
//  return(D);
//}
arma::mat makeDistARMA(const arma::mat & coords1, const arma::mat & coords2) {
  int nrows1 = coords1.n_rows;
  int nrows2 = coords2.n_rows;
  arma::mat D(nrows1, nrows2, arma::fill::zeros);
  int ncols1 = coords1.n_cols;
  if(ncols1 == 1){
    for(int i = 0; i < nrows1; i++){
      for(int j = 0; j < nrows2; j++){
        D(i, j) = sqrt(pow(coords1(i) - coords2(j), 2));
      }
    }
  }
  if(ncols1 == 2){  
    for(int i = 0; i < nrows1; i++){
      for(int j = 0; j < nrows2; j++){
        double tmp = 0;
        for(int k = 0; k < 2; k++){
        tmp += pow(coords1(i, k) - coords2(j, k), 2);
        }
        D(i, j) = sqrt(tmp);
      }
    }
  }
  return(D);
}

// c++ verision of the R function princomp
Rcpp::List makePCA(const arma::mat X){ // recreate in C++ the R function princomp
  int nrows = X.n_rows;
  arma::vec J(nrows, arma::fill::ones);
  int ncols = X.n_cols;
  arma::mat X_center(nrows, ncols);
  for(int i = 0; i < ncols; i++){
    X_center.col(i) = X.col(i) - J * mean(X.col(i));
  }
  arma::mat U;
  arma::vec s;
  arma::mat V;
  arma::svd_econ(U, s, V, X_center, "right", "dc");
  return(Rcpp::List::create(
    Rcpp::_["V"] = V,
    Rcpp::_["X_pca"] = X_center * V, 
    Rcpp::_["sdev"] = s / sqrt(nrows - 1)));
}

// construct the CAR precision matrix for a time series
arma::mat makeQinv(const double& theta, const int& t){ // CAR precision matrix
  arma::mat out(t, t, arma::fill::eye);
  arma::vec toep_vec(t, arma::fill::zeros);
	toep_vec(1) = 1;
	arma::vec diag_vec(t, arma::fill::zeros);
	for(int i = 1; i < (t - 1); i++){
		diag_vec(i) = pow(theta, 2);
	}
	out.diag() += diag_vec;
	return(out - theta * arma::toeplitz(toep_vec));
}

// simulate many realizations from a multivariate normal
arma::mat mvrnormArma(const int & n, const arma::vec & mu, 
                      const arma::mat & Sigma){
   int ncols = Sigma.n_cols;
   arma::mat Z = arma::randn(n, ncols);
   return repmat(mu, 1, n).t() + Z * chol(Sigma);
}

// simulate one realization from a multivariate normal
arma::vec mvrnormArmaVec(const arma::vec & mu, const arma::mat & Sigma) {
   int ncols = Sigma.n_cols;
   arma::vec z = arma::randn(ncols);
   return mu + chol(Sigma) * z;
}
// simulate many realizations from a multivariate normal from Cholesky
arma::mat mvrnormArmaChol(const int & n, const arma::vec & mu, 
                          const arma::mat & Sigma_chol) {
  int ncols = Sigma_chol.n_cols;
  arma::mat Z = arma::randn(n, ncols);
  return repmat(mu, 1, n).t() + Z * Sigma_chol;
}

// simulate one realizations from a multivariate normal from Cholesky
arma::vec mvrnormArmaVecChol(const arma::vec & mu, const arma::mat & Sigma_chol) {
  int ncols = Sigma_chol.n_cols;
  arma::vec z = arma::randn(ncols);
  return mu + Sigma_chol * z;
}

// order an arma vector
Rcpp::IntegerVector orderArma(const Rcpp::NumericVector x) {
  if (is_true(any(duplicated(x)))) {
    Rf_warning("There are duplicates in 'x'; order not guaranteed to match that of R's base::order");
  }
  Rcpp::NumericVector sorted = clone(x).sort();
  return match(sorted, x);
}

// read in a Armadillo cube
arma::cube readCube(const Rcpp::NumericVector myArray){
  Rcpp::NumericVector vecArray(myArray);
  Rcpp::IntegerVector arrayDims = vecArray.attr("dim");
  arma::cube cubeArray(vecArray.begin(), arrayDims(0), arrayDims(1), arrayDims(2));
  return(cubeArray);
}

// rbind in ARMA
arma::mat rbindARMA(const arma::mat& A, const arma::mat& B){
  int ncols = A.n_cols;    
  int nrowsA = A.n_rows;
  int nrowsB = B.n_rows;
  arma::mat out(nrowsA + nrowsB, ncols);
  for(int i = 0; i < nrowsA + nrowsB; i++){
    if(i < nrowsA){
      out.row(i) = A.row(i);
    } else {
      out.row(i) = B.row(i - nrowsA);
    }
  }
  return(out);
}

// simulate from an inverse Gaussian (Wald) distribution
double rInvGauss(const double& mu, const double& lambda) {
  double z = R::rnorm(0, 1);
  double y = z*z;
  double x = mu + (mu*mu*y) / (2.0*lambda) - (mu / (2.0*lambda)) * sqrt(4.0*mu*lambda*y + mu*mu*y*y);
  double test = R::runif(0, 1);
  if(test <= (mu)/(mu + x)){
    return(x);
  } else {
    return(mu*mu/x);
  }
}

// simulate from a multivatiate normal given by a full conditional mean A^(-1) * b, var A^(-1)
arma::vec rMVNArma(arma::mat& A, arma::vec& b){
  int ncols = A.n_cols;
  arma::mat A_chol(ncols, ncols);
  bool success = false;
  int counter = 0;
  while(success == false && counter < 100){
    success = arma::chol(A_chol, A);
    if(success == false){
      counter++;
      A += arma::mat(ncols, ncols, arma::fill::eye) * 1e-6;
    }
  }
  arma::vec devs = arma::randn(ncols);
	arma::vec temp = solve(trimatl(A_chol.t()), b);
	return arma::vec(solve(trimatu(A_chol), temp + devs));
}

// simulate from a univariate normal given by a full conditional mean 1 / a * b, var 1 / a
double rMVNArmaScalar(const double& a, const double& b){
  double a_inv = 1.0 / a;
  double z = R::rnorm(0, 1);
  return(b * a_inv + z * sqrt(a_inv));
}

// simulate from a Wishart distribution
//  arma::cube rWishartArma(const int& n, const int& df, 
//                            const arma::mat& Sig){
//    int ncols = Sig.n_cols;
//    arma::cube out_array(ncols, ncols, n, arma::fill::zeros);
//    arma::mat Sig_chol = chol(Sig);
//    for(int i=0; i<n; i++){
//      arma::mat devs(ncols, df, fill::randn);
//      arma::mat X = Sig_chol * devs;
//      out_array.slice(i) = X * X.t();
//    }
//    return(out_array);
// //  }
// 
// arma::mat rWishartArmaMat(const int& df, const arma::mat& Sig){
//   int ncols = Sig.n_cols;
//   arma::mat Sig_chol = chol(Sig);
//   arma::mat devs(ncols, df, arma::fill::randn);
//   arma::mat X = Sig_chol * devs;
//   return(X * X.t());
// }

// Balamuta style
arma::mat rWishartArmaMat(const unsigned int df, const arma::mat& S){
  // Dimension of returned wishart
  unsigned int m = S.n_rows;
  
  // Z composition:
  // sqrt chisqs on diagonal
  // random normals below diagonal
  // misc above diagonal
  arma::mat Z(m,m);
  
  // Fill the diagonal
  for(unsigned int i = 0; i < m; i++){
    Z(i,i) = sqrt(R::rchisq(df-i));
  }
  
  // Fill the lower matrix with random guesses
  for(unsigned int j = 0; j < m; j++){  
    for(unsigned int i = j+1; i < m; i++){    
      Z(i,j) = R::rnorm(0,1);
    }
  }
  
  // Lower triangle * chol decomp
  arma::mat C = arma::trimatl(Z).t() * arma::chol(S);
  
  // Return random wishart
  return C.t()*C;
}

// Balamuta style
arma::mat rIWishartArmaMat(const unsigned int df, const arma::mat& S){
  return rWishartArmaMat(df,S.i()).i();
}

// Wishart Density
double dWishartArma (const arma::mat& Sig, const double& nu, 
                     const arma::mat& S, bool logd=true) {
  double p = Sig.n_rows;
  double lgamma_tmp = 0.0;
  for (int j=0; j<p; j++) {
    lgamma_tmp += lgamma(0.5*nu + 0.5*(1.0-(j+1.0)));
  }
  arma::mat diag_mat_tmp = inv_sympd(S) * Sig;
  double logdensity = 0.5*(nu-p-1)*logDet(Sig) - 
    0.5*sum(diag_mat_tmp.diag()) - 0.5*p*nu*log(2.0) - 
    0.5*nu*logDet(S) - 0.25*p*(p-1)*log(arma::datum::pi) - lgamma_tmp;
  if (logd) {
    return(logdensity);
  } else {
    return(exp(logdensity));
  }
}

// rowMeans function
arma::vec rowMeans(const arma::mat& X){
  int nRows = X.n_rows;
  arma::vec out(nRows);
  for(int i = 0; i < nRows; i++){
    out(i) = mean(X.row(i));
  }
  return(out);
}

// rowSds function
arma::vec rowSds(const arma::mat& X){
  int nRows = X.n_rows;
  arma::vec out(nRows);
  for(int i = 0; i < nRows; i++){
    out(i) = stddev(X.row(i));
  }
  return(out);
}

// calculate rowSums
arma::vec rowSums(const arma::mat & X){
   int nRows = X.n_rows;
   arma::vec out(nRows);
   for(int i = 0; i < nRows; i++){
      out(i) = sum(X.row(i));
   }
   return(out);
}

// calculate the SVD using the "standard" method
Rcpp::List svdARMA(const arma::mat & X) {
    arma::mat U, V;
    arma::vec S;
    svd(U, S, V, X, "standard");
    return Rcpp::List::create(Rcpp::Named("sd") = S, Rcpp::Named("U") = U, Rcpp::Named("V") = V);
}

// calculate the SVD using the "divide and conquer" method
Rcpp::List dcsvdARMA(const arma::mat & X) {
    arma::mat U, V;
    arma::vec S;
    svd(U, S, V, X, "dc");
    return Rcpp::List::create(Rcpp::Named("sd") = S, Rcpp::Named("U") = U);
}

// function to update adaptive tuning for a scalar
void updateTuning(const int k, double& accept_tmp, double& tune){
  double delta = 1.0 / sqrt(k);
  if(accept_tmp > 0.44){
    tune = exp(log(tune) + delta);
  } else {
    tune = exp(log(tune) - delta);
  }
  accept_tmp = 0.0;
}

// function to update adaptive tuning for a vector
void updateTuningVec(const int k, arma::vec& accept_tmp, arma::vec& tune){
  double delta = 1.0 / sqrt(k);
  int n = tune.n_elem;
  for(int i = 0; i < n; i++){
    if(accept_tmp(i) > 0.44){
      tune(i) = exp(log(tune(i)) + delta);
    } else {
      tune(i) = exp(log(tune(i)) - delta);
    }
    accept_tmp(i) = 0.0;
  }
}

// function to update adaptive tuning for a matrix
void updateTuningMat(const int k, arma::mat& accept_tmp, arma::mat& tune){
  double delta = 1.0 / sqrt(k);
  int n = tune.n_rows;
  int p = tune.n_cols;
  for(int i = 0; i < n; i++){
    for(int j = 0; j < p; j++){
      if(accept_tmp(i, j) > 0.44){
        tune(i, j) = exp(log(tune(i, j)) + delta);
      } else {
        tune(i, j) = exp(log(tune(i, j)) - delta);
      }
      accept_tmp(i, j) = 0.0;
    }
  }
}

// function to update adaptive tuning for a multivariate proposal
void updateTuningMV(const int& k, const arma::vec& x, arma::vec& mu,
                    arma::mat& Sig){
  double delta = 1.0 / (k + 1.0);
  arma::vec tmp = (x - mu);
  mu += delta * tmp;
  Sig += delta * (tmp * tmp.t() - Sig);
}

