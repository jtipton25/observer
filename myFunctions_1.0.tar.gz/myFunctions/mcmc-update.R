library(data.table)

out <- data.frame(
  array(3.5*1:1000, dim=c(1000, 100, 100), 
        dimnames=list(a=1:1000, b=1:100, c=1:100)))

fwrite.mcmc <- function(x, file, path="./") {
  ## Note, to use, leave off the file type .csv
  ##
  ## To Do
  ## 1) check if file already exists
  ## 2) if file exists, append the existing file
  ## 3) update n_mcmc
  file.list <- list.files(path)
  if (paste(file, ".csv", sep="") %in% file.list) {
    k <- fread(paste(file, 'k.csv', sep=''))
    k <- data.frame(n_mcmc = dim(x)[1] + k$n_mcmc)
    fwrite(x, file.path=paste(file, ".csv", sep=""), append=TRUE)
    fwrite(k, file.path=paste(file, 'k.csv', sep=''))
  } else {
    k <- data.frame(n_mcmc = dim(x)[1])
    fwrite(k, file=paste(file, 'k.csv', sep=''))
    fwrite(x, file.path=paste(file, ".csv", sep=""))  
  }
}

fread.mcmc <- function(file) {
  k <- fread(paste("largetestfile", 'k.csv', sep=''))
  out <- fread(paste("largetestfile", '.csv', sep=''), skip=k$n_mcmc)
  return(list(out=out, n_mcmc=k$n_mcmc))
}


fwrite.mcmc(out, "largetestfile")
tmp=fread.mcmc("largetestfile")


tmp=fread("largetestfile.csv")
