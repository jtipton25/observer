#include <RcppArmadillo.h>

// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::interfaces(r, cpp)]]

using namespace Rcpp;
using namespace arma;

//  // [[Rcpp::export]]
// arma::cube rWishartArma(const int& n, const int& df, 
//                          const arma::mat& Sig){
//	int ncols = Sig.n_cols;
//  arma::cube out_array(ncols, ncols, n, fill::zeros);
//  arma::mat Sig_chol = chol(Sig);
//  for(int i=0; i<n; i++){
//    arma::mat devs(ncols, df, fill::randn);
//    arma::mat X = Sig_chol * devs;
//    out_array.slice(i) = X * X.t();
//  }
//  return(out_array);
//}


// [[Rcpp::export]]
arma::mat rWishartArmaMat(const int& df, const arma::mat& Sig){
  int ncols = Sig.n_cols;
  arma::mat Sig_chol = chol(Sig);
  arma::mat devs(ncols, df, fill::randn);
  arma::mat X = Sig_chol * devs;
  return(X * X.t());
}