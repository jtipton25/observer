#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::interfaces(r)]]

using namespace Rcpp;
using namespace arma;

//' A sampler for inverse Gaussian (Wald) random variables
//'
//' @param mu
//'  
//' @return a random variate
//' @export
// [[Rcpp::export]]

double rInvGauss(const double& mu, const double& lambda) {
  double z = R::rnorm(0, 1);
  double y = z*z;
  double x = mu + (mu*mu*y) / (2.0*lambda) - (mu / (2.0*lambda)) * sqrt(4.0*mu*lambda*y + mu*mu*y*y);
  double test = R::runif(0, 1);
  if(test <= (mu)/(mu + x)){
    return(x);
  } else {
    return(mu*mu/x);
  }
}

