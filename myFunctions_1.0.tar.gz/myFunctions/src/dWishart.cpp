#include <RcppArmadillo.h>
using namespace Rcpp;
// [[Rcpp::depends(RcppArmadillo)]]


double logDetWish(const arma::mat Sig) {
  arma::mat rooti = chol(Sig);
  return(2.0 * sum(log(rooti.diag())));
}

// [[Rcpp::export]]
double dWishartArma (const arma::mat& Sig, const double& nu, 
                     const arma::mat& S, bool logd=true) {
  double p = Sig.n_rows;
  double lgamma_tmp = 0.0;
  for (int j=0; j<p; j++) {
    lgamma_tmp += lgamma(0.5*nu + 0.5*(1.0-(j+1.0)));
  }
  arma::mat diag_mat_tmp = inv_sympd(S) * Sig;
  double logdensity = 0.5*(nu-p-1)*logDetWish(Sig) - 
    0.5*sum(diag_mat_tmp.diag()) - 0.5*p*nu*log(2.0) - 
    0.5*nu*logDetWish(S) - 0.25*p*(p-1)*log(arma::datum::pi) - lgamma_tmp;
  if (logd) {
    return(logdensity);
  } else {
    return(exp(logdensity));
  }
}
