##
## Libraries and Subroutines
##

## make true spatial field
## change the nugget effect
# make.Z.list <- function(reps, mu, Sig.s, m){
#   mu + t(chol(Sig.s)) %*% rnorm(m)
# }

makeZlist <- function(reps, mu, Sig, m){
  mu + t(chol(Sig)) %*% rnorm(m)
}

## make sampling matrix H
makeHlist <- function(reps, samp, m){
  (1:m)[samp[[reps]]]
}

## make sampling matrix H_minus
makeHMinuslist <- function(reps, samp, m){
  (1:m)[ - samp[[reps]]]
}

makeYlist <- function(reps, Z_list, H_list, s2_e){
  Z_list[[reps]][H_list[[reps]]]
}

plotZfield <- function(Z_list, locs, main = "Observed Data", ylab = "Y", xlab = "X"){
  reps <- length(Z_list)
  min_Z <- min(unlist(lapply(Z_list, min)))
  max_Z <- max(unlist(lapply(Z_list, max)))
  plot(Z_list[[1]] ~ locs, type = 'l', ylim = c(min_Z, max_Z), main = main,
       ylab = ylab, xlab = xlab, col = 1)
  for(t in 2:reps){
    lines(Z_list[[t]] ~ locs, type = 'l', col = t)
  }
}

plotYfield <- function(Y_list, H_list, locs, main = "Observed Data", 
                       ylab = "Y", xlab = "X"){
  reps <- length(Y_list)
  min_Y <- min(unlist(lapply(Y_list, min)))
  max_Y <- max(unlist(lapply(Y_list, max)))
  idx <- order(locs[H_list[[1]]])
  plot(Y_list[[1]][idx] ~ locs[H_list[[1]]][idx], type = 'l', 
       ylim = c(min_Y, max_Y), main = main, ylab = ylab, xlab = xlab)
  for(t in 2:reps){
    idx <- order(locs[H_list[[t]]])
    lines(Y_list[[t]][idx] ~ locs[H_list[[t]]][idx], type = 'l', col = t)
  }
}

####
####  Simulate 1-D spatial random fields with trend
####

makeSpatialField <- function(reps, X, beta, locs, param = c(s2_s, phi), 
                             method = 'exponential', s2_e, samp_size){
  m <- dim(X)[1]
  mu <- X %*% beta # mean function
  ## Exponential Spatial Decay Function s2.s * exp( - D / phi)
  if(method == 'exponential'){
    s2_s <- param[1]
    phi <- param[2]
    D <- as.matrix(dist(locs)) # distance matrix
    Sig_s <- s2_s * exp( - D * phi) # spatial covariance matrix
    Sig <- Sig_s + s2_e * diag(dim(D)[2])
#     Sig_s_inv <- solve(Sig_s) 
  } else if(method == 'gaussian'){
    s2_s <- param[1]
    phi <- param[2]
    D <- as.matrix(dist(locs)) # distance matrix
    Sig_s <- s2_s * exp( - D^2 * phi) # spatial covariance matrix
    Sig <- Sig_s + s2_e * diag(dim(D)[2])
  }

  ## Simulate Random Field with nugget
  Z_list <- lapply(1:reps, makeZlist, mu = mu, Sig = Sig, m = m)
           
  ##  Subsample Fields    
  #samp <- rep(list(sample(1:m, samp.size)), reps)
  tmp_vec = sin(0.025 * (1:m))
  p_vec = tmp_vec - min(tmp_vec)
  samp <- vector('list', length = reps)
  for(i in 1:reps){
      samp[[i]] <- sample(1:m, sample(samp_size, 1), prob = p_vec)
  }
  H_list <- lapply(1:reps, makeHlist, samp = samp, m = m)
  HMinus_list <- lapply(1:reps, makeHMinuslist, samp = samp, m = m)
#   Y.list <- lapply(1:reps, make.Y.list, Z.list = Z.list, H.list = H.list, s2.e = s2.e)
  Y_list <- lapply(1:reps, makeYlist, Z_list = Z_list, H_list = H_list)
  ## write output
  list(Z_list = Z_list, Y_list = Y_list, H_list = H_list, HMinus_list=HMinus_list)
}
