load("~/spatialModeling/data/fortTempData.RData")
loc.id <- list(length = 73)

for(i in 1:73){
  loc.id[[i]] <- vector(length = dim(year[[i]][, 1:2])[1])
  for(j in 1:dim(year[[i]][, 1:2])[1]){
    if(is.null(dim(test.dist[[i]])) == TRUE){
      loc.id[[i]][j] <- which(test.dist[[i]] == min(test.dist[[i]]))
    } else {
      loc.id[[i]][j] <-  - (j - 1) * dim(test.dist[[i]])[1] + which(test.dist[[i]] == min(test.dist[[i]][, j])) 
    }
  }
  cat(" ", i)
}

rm(all.temp, avg, D, data, fort.points, H.list.dup, i, j, july.temp, make.sum, test.dist, X, X.temp, year, year.1)

save.image("~/fortFunctions/data/fortFunctions.rda")
