make_diagnostics <- function(samps, t, p, nobs, model, type) {
  library(coda)
  if (model == "pca_ssvs") {
    Rhat <- list()
    Rhat$beta <- gelman.diag(samps[, paste("beta[", 1:p,",", 1:t,"]", sep="")], 
                             autoburnin=FALSE, multivariate=FALSE)
    Rhat$gamma <- gelman.diag(samps[, paste("gamma[", 1:p,",", 1:t,"]", sep="")],
                              autoburnin=FALSE, multivariate=FALSE)
    Rhat$s_inv <- gelman.diag(samps[, paste("s_inv[", 1:t,"]", sep="")], 
                              autoburnin=FALSE, multivariate=FALSE)
    Rhat$tau2_beta <- gelman.diag(samps[, paste("tau2_beta[", 1:t,"]", sep="")],
                                  autoburnin=FALSE, multivariate=FALSE)
    
    par(mar=c(5, 4, 4, 2) + 0.1)
    layout(matrix(1:4, 2, 2))
    hist(Rhat$beta$psrf[, 1], main="beta", breaks=100)
    abline(v=max(Rhat$beta$psrf[, 1]), col="red")
    hist(Rhat$gamma$psrf[, 1], main="gamma", breaks=100)
    abline(v=max(Rhat$gamma$psrf[, 1]), col="red")
    hist(Rhat$s_inv$psrf[, 1], main="s_inv", breaks=100)
    abline(v=max(Rhat$s_inv$psrf[, 1]), col="red")
    hist(Rhat$tau2_beta$psrf[, 1], main="tau2_beta", breaks=100)
    abline(v=max(Rhat$tau2_beta$psrf[, 1]), col="red")
    # if (type == "sim") {
    #   write.csv(Rhat, file="./diagnostics/sim/pca_ssvs_Rhat.csv")
    # } else if (type == "observer") {
    #   write.csv(Rhat, file="./diagnostics/observer/pca_ssvs_Rhat.csv")
    # } else if (type == "outlier-removed") {
    #   write.csv(Rhat, file="./diagnostics/outlier-removed/pca_ssvs_Rhat.csv")
    # } else {
    #   stop("enter a valid type")
    # }
  } else if (model == "pca_lasso") {
    Rhat <- list()
    Rhat$beta <- gelman.diag(samps[, paste("beta[", 1:p,",", 1:t,"]", sep="")], 
                             autoburnin=FALSE, multivariate=FALSE)
    Rhat$gamma2 <- gelman.diag(samps[, paste("gamma2[", 1:p,",", 1:t,"]", sep="")],
                               autoburnin=FALSE, multivariate=FALSE)
    Rhat$s_inv <- gelman.diag(samps[, paste("s_inv[", 1:t,"]", sep="")], 
                              autoburnin=FALSE, multivariate=FALSE)
    Rhat$lambda2 <- gelman.diag(samps[, paste("lambda2[", 1:t,"]", sep="")],
                                autoburnin=FALSE, multivariate=FALSE)
    
    par(mar=c(5, 4, 4, 2) + 0.1)
    layout(matrix(1:4, 2, 2))
    hist(Rhat$beta$psrf[, 1], main="beta", breaks=100)
    abline(v=max(Rhat$beta$psrf[, 1]), col="red")
    hist(Rhat$gamma2$psrf[, 1], main="gamma2", breaks=100)
    abline(v=max(Rhat$gamma$psrf[, 1]), col="red")
    hist(Rhat$s_inv$psrf[, 1], main="s_inv", breaks=100)
    abline(v=max(Rhat$s_inv$psrf[, 1]), col="red")
    hist(Rhat$lambda2$psrf[, 1], main="lambda2", breaks=100)
    abline(v=max(Rhat$lambda2$psrf[, 1]), col="red")
    # if (type == "sim") {
    #   write.csv(Rhat, file="./diagnostics/sim/pca_lasso_Rhat.csv")
    # } else if (type == "observer") {
    #   write.csv(Rhat, file="./diagnostics/observer/pca_lasso_Rhat.csv")
    # } else if (type == "outlier-removed") {
    #   write.csv(Rhat, file="./diagnostics/outlier-removed/pca_lasso_Rhat.csv")
    # } else {
    #   stop("enter a valid type")
    # }
    
  } else if (model == "tpca_ssvs") {
    Rhat <- list()
    Rhat$beta <- gelman.diag(samps[, paste("beta[", 1:p,",", 1:t,"]", sep="")], 
                             autoburnin=FALSE, multivariate=FALSE)
    Rhat$gamma <- gelman.diag(samps[, paste("gamma[", 1:p,",", 1:t,"]", sep="")],
                              autoburnin=FALSE, multivariate=FALSE)
    Rhat$s_inv <- gelman.diag(samps[, paste("s_inv[", 1:t,"]", sep="")], 
                              autoburnin=FALSE, multivariate=FALSE)
    Rhat$nu <- gelman.diag(samps[, paste("nu[", 1:t,"]", sep="")], 
                           autoburnin=FALSE, multivariate=FALSE)
    Rhat$tau2_beta <- gelman.diag(samps[, paste("tau2_beta[", 1:t,"]", sep="")],
                                  autoburnin=FALSE, multivariate=FALSE)
    Rhat$v_inv <- gelman.diag(samps[, paste("v_inv[", 1:t,"]", sep="")],
                              autoburnin=FALSE, multivariate=FALSE)
    
    par(mar=c(5, 4, 4, 2) + 0.1)
    layout(matrix(1:6, 3, 2))
    hist(Rhat$beta$psrf[, 1], main="beta", breaks=100)
    abline(v=max(Rhat$beta$psrf[, 1]), col="red")
    hist(Rhat$gamma$psrf[, 1], main="gamma", breaks=100)
    abline(v=max(Rhat$gamma$psrf[, 1]), col="red")
    hist(Rhat$s_inv$psrf[, 1], main="s_inv", breaks=100)
    abline(v=max(Rhat$s_inv$psrf[, 1]), col="red")
    hist(Rhat$nu$psrf[, 1], main="nu", breaks=100)
    abline(v=max(Rhat$nu$psrf[, 1]), col="red")
    hist(Rhat$tau2_beta$psrf[, 1], main="tau2_beta", breaks=100)
    abline(v=max(Rhat$tau2_beta$psrf[, 1]), col="red")
    hist(Rhat$v_inv$psrf[, 1], main="v_inv", breaks=100)
    abline(v=max(Rhat$v_inv$psrf[, 1]), col="red")
    # if (type == "sim") {
    #   write.csv(Rhat, file="./diagnostics/sim/tpca_ssvs_Rhat.csv")
    # } else if (type == "observer") {
    #   write.csv(Rhat, file="./diagnostics/observer/tpca_ssvs_Rhat.csv")
    # } else if (type == "outlier-removed") {
    #   write.csv(Rhat, file="./diagnostics/outlier-removed/tpca_ssvs_Rhat.csv")
    # } else {
    #   stop("enter a valid type")
    # }
    
  } else if (model == "tpca_lasso") {
    Rhat <- list()
    Rhat$beta <- gelman.diag(samps[, paste("beta[", 1:p,",", 1:t,"]", sep="")], 
                             autoburnin=FALSE, multivariate=FALSE)
    Rhat$gamma2 <- gelman.diag(samps[, paste("gamma2[", 1:p,",", 1:t,"]", sep="")],
                               autoburnin=FALSE, multivariate=FALSE)
    Rhat$s_inv <- gelman.diag(samps[, paste("s_inv[", 1:t,"]", sep="")], 
                              autoburnin=FALSE, multivariate=FALSE)
    Rhat$lambda2 <- gelman.diag(samps[, paste("lambda2[", 1:t,"]", sep="")],
                                autoburnin=FALSE, multivariate=FALSE)
    Rhat$v_inv <- gelman.diag(samps[, paste("v_inv[", 1:t,"]", sep="")],
                              autoburnin=FALSE, multivariate=FALSE)
    Rhat$nu <- gelman.diag(samps[, paste("nu[", 1:t,"]", sep="")], 
                           autoburnin=FALSE, multivariate=FALSE)
    
    
    par(mar=c(5, 4, 4, 2) + 0.1)
    layout(matrix(1:6, 3, 2))
    hist(Rhat$beta$psrf[, 1], main="beta", breaks=100)
    abline(v=max(Rhat$beta$psrf[, 1]), col="red")
    hist(Rhat$gamma2$psrf[, 1], main="gamma2", breaks=100)
    abline(v=max(Rhat$gamma$psrf[, 1]), col="red")
    hist(Rhat$s_inv$psrf[, 1], main="s_inv", breaks=100)
    abline(v=max(Rhat$s_inv$psrf[, 1]), col="red")
    hist(Rhat$lambda2$psrf[, 1], main="lambda2", breaks=100)
    abline(v=max(Rhat$lambda2$psrf[, 1]), col="red")
    hist(Rhat$v_inv$psrf[, 1], main="v_inv", breaks=100)
    abline(v=max(Rhat$v_inv$psrf[, 1]), col="red")
    hist(Rhat$nu$psrf[, 1], main="nu", breaks=100)
    abline(v=max(Rhat$nu$psrf[, 1]), col="red")
    # if (type == "sim") {
    #   write.csv(Rhat, file="./diagnostics/sim/tpca_lasso_Rhat.csv")
    # } else if (type == "observer") {
    #   write.csv(Rhat, file="./diagnostics/observer/tpca_lasso_Rhat.csv")
    # } else if (type == "outlier-removed") {
    #   write.csv(Rhat, file="./diagnostics/outlier-removed/tpca_lasso_Rhat.csv")
    # } else {
    #   stop("enter a valid type")
    # }
    
  } else if (model == "ppca_ssvs") {
    Rhat <- list()
    Rhat$beta <- gelman.diag(samps[, paste("beta[", 1:p,",", 1:t,"]", sep="")], 
                             autoburnin=FALSE, multivariate=FALSE)
    Rhat$gamma <- gelman.diag(samps[, paste("gamma[", 1:p,",", 1:t,"]", sep="")],
                              autoburnin=FALSE, multivariate=FALSE)
    Rhat$tau2 <- gelman.diag(samps[, paste("tau2[", 1:t,"]", sep="")], 
                             autoburnin=FALSE, multivariate=FALSE)
    Rhat$s2 <- gelman.diag(samps[, "s2"], 
                           autoburnin=FALSE, multivariate=FALSE)
    Rhat$tau2_beta <- gelman.diag(samps[, paste("tau2_beta[", 1:t,"]", sep="")],
                                  autoburnin=FALSE, multivariate=FALSE)
    
    par(mar=c(5, 4, 4, 2) + 0.1)
    layout(matrix(1:6, 3, 2))
    hist(Rhat$beta$psrf[, 1], main="beta", breaks=100)
    abline(v=max(Rhat$beta$psrf[, 1]), col="red")
    hist(Rhat$gamma$psrf[, 1], main="gamma", breaks=100)
    abline(v=max(Rhat$gamma$psrf[, 1]), col="red")
    hist(Rhat$tau2$psrf[, 1], main="tau2", breaks=100)
    abline(v=max(Rhat$tau2$psrf[, 1]), col="red")
    hist(Rhat$s2$psrf[, 1], main="s2", breaks=100)
    abline(v=max(Rhat$s2$psrf[, 1]), col="red")
    hist(Rhat$tau2_beta$psrf[, 1], main="tau2_beta", breaks=100)
    abline(v=max(Rhat$tau2_beta$psrf[, 1]), col="red")
    # if (type == "sim") {
    #   write.csv(Rhat, file="./diagnostics/sim/ppca_ssvs_Rhat.csv")
    # } else if (type == "observer") {
    #   write.csv(Rhat, file="./diagnostics/observer/ppca_ssvs_Rhat.csv")
    # } else if (type == "outlier-removed") {
    #   write.csv(Rhat, file="./diagnostics/outlier-removed/ppca_ssvs_Rhat.csv")
    # } else {
    #   stop("enter a valid type")
    # }
    
  } else if (model == "ppca_lasso") {
    Rhat <- list()
    Rhat$beta <- gelman.diag(samps[, paste("beta[", 1:p,",", 1:t,"]", sep="")], 
                             autoburnin=FALSE, multivariate=FALSE)
    Rhat$gamma2 <- gelman.diag(samps[, paste("gamma2[", 1:p,",", 1:t,"]", sep="")],
                               autoburnin=FALSE, multivariate=FALSE)
    Rhat$lambda2 <- gelman.diag(samps[, paste("lambda2[", 1:t,"]", sep="")],
                                autoburnin=FALSE, multivariate=FALSE)
    Rhat$tau2 <- gelman.diag(samps[, paste("tau2[", 1:t,"]", sep="")], 
                             autoburnin=FALSE, multivariate=FALSE)
    Rhat$s2 <- gelman.diag(samps[, "s2"], 
                           autoburnin=FALSE, multivariate=FALSE)
    
    par(mar=c(5, 4, 4, 2) + 0.1)
    layout(matrix(1:6, 3, 2))
    hist(Rhat$beta$psrf[, 1], main="beta", breaks=100)
    abline(v=max(Rhat$beta$psrf[, 1]), col="red")
    hist(Rhat$gamma2$psrf[, 1], main="gamma2", breaks=100)
    abline(v=max(Rhat$gamma2$psrf[, 1]), col="red")
    hist(Rhat$lambda2$psrf[, 1], main="lambda2", breaks=100)
    abline(v=max(Rhat$lambda2$psrf[, 1]), col="red")
    hist(Rhat$tau2$psrf[, 1], main="tau2", breaks=100)
    abline(v=max(Rhat$tau2$psrf[, 1]), col="red")
    hist(Rhat$s2$psrf[, 1], main="s2", breaks=100)
    abline(v=max(Rhat$s2$psrf[, 1]), col="red")
    # if (type == "sim") {
    #   write.csv(Rhat, file="./diagnostics/sim/ppca_lasso_Rhat.csv")
    # } else if (type == "observer") {
    #   write.csv(Rhat, file="./diagnostics/observer/ppca_lasso_Rhat.csv")
    # } else if (type == "outlier-removed") {
    #   write.csv(Rhat, file="./diagnostics/outlier-removed/ppca_lasso_Rhat.csv")
    # } else {
    #   stop("enter a valid type")
    # }
  } else if (model == "tppca_ssvs") {
    Rhat <- list()
    Rhat$beta <- gelman.diag(samps[, paste("beta[", 1:p,",", 1:t,"]", sep="")], 
                             autoburnin=FALSE, multivariate=FALSE)
    Rhat$gamma <- gelman.diag(samps[, paste("gamma[", 1:p,",", 1:t,"]", sep="")],
                              autoburnin=FALSE, multivariate=FALSE)
    Rhat$tau2 <- gelman.diag(samps[, paste("tau2[", 1:t,"]", sep="")], 
                             autoburnin=FALSE, multivariate=FALSE)
    Rhat$s2 <- gelman.diag(samps[, "s2"], 
                           autoburnin=FALSE, multivariate=FALSE)
    Rhat$tau2_beta <- gelman.diag(samps[, paste("tau2_beta[", 1:t,"]", sep="")],
                                  autoburnin=FALSE, multivariate=FALSE)
    Rhat$nu <- gelman.diag(samps[, paste("nu[", 1:t,"]", sep="")], 
                           autoburnin=FALSE, multivariate=FALSE)
    Rhat$v_inv <- gelman.diag(samps[, paste("v_inv[", 1:t,"]", sep="")],
                              autoburnin=FALSE, multivariate=FALSE)
    
    par(mar=c(5, 4, 4, 2) + 0.1)
    layout(matrix(1:9, 3, 3))
    hist(Rhat$beta$psrf[, 1], main="beta", breaks=100)
    abline(v=max(Rhat$beta$psrf[, 1]), col="red")
    hist(Rhat$gamma$psrf[, 1], main="gamma", breaks=100)
    abline(v=max(Rhat$gamma$psrf[, 1]), col="red")
    hist(Rhat$tau2$psrf[, 1], main="tau2", breaks=100)
    abline(v=max(Rhat$tau2$psrf[, 1]), col="red")
    hist(Rhat$s2$psrf[, 1], main="s2", breaks=100)
    abline(v=max(Rhat$s2$psrf[, 1]), col="red")
    hist(Rhat$tau2_beta$psrf[, 1], main="tau2_beta", breaks=100)
    abline(v=max(Rhat$tau2_beta$psrf[, 1]), col="red")
    hist(Rhat$nu$psrf[, 1], main="nu", breaks=100)
    abline(v=max(Rhat$nu$psrf[, 1]), col="red")
    hist(Rhat$v_inv$psrf[, 1], main="v_inv", breaks=100)
    abline(v=max(Rhat$v_inv$psrf[, 1]), col="red")
    # if (type == "sim") {
    #   write.csv(Rhat, file="./diagnostics/sim/tppca_ssvs_Rhat.csv")
    # } else if (type == "observer") {
    #   write.csv(Rhat, file="./diagnostics/observer/tppca_ssvs_Rhat.csv")
    # } else if (type == "outlier-removed") {
    #   write.csv(Rhat, file="./diagnostics/outlier-removed/tppca_ssvs_Rhat.csv")
    # } else {
    #   stop("enter a valid type")
    # }
    
  } else if (model == "tppca_lasso") {
    Rhat <- list()
    Rhat$beta <- gelman.diag(samps[, paste("beta[", 1:p,",", 1:t,"]", sep="")], 
                             autoburnin=FALSE, multivariate=FALSE)
    Rhat$gamma2 <- gelman.diag(samps[, paste("gamma2[", 1:p,",", 1:t,"]", sep="")],
                               autoburnin=FALSE, multivariate=FALSE)
    Rhat$lambda2 <- gelman.diag(samps[, paste("lambda2[", 1:t,"]", sep="")],
                                autoburnin=FALSE, multivariate=FALSE)
    Rhat$tau2 <- gelman.diag(samps[, paste("tau2[", 1:t,"]", sep="")], 
                             autoburnin=FALSE, multivariate=FALSE)
    Rhat$s2 <- gelman.diag(samps[, "s2"], 
                           autoburnin=FALSE, multivariate=FALSE)
    Rhat$nu <- gelman.diag(samps[, paste("nu[", 1:t,"]", sep="")], 
                           autoburnin=FALSE, multivariate=FALSE)
    Rhat$v_inv <- gelman.diag(samps[, paste("v_inv[", 1:t,"]", sep="")],
                              autoburnin=FALSE, multivariate=FALSE)
    
    par(mar=c(5, 4, 4, 2) + 0.1)
    layout(matrix(1:9, 3, 3))
    hist(Rhat$beta$psrf[, 1], main="beta", breaks=100)
    abline(v=max(Rhat$beta$psrf[, 1]), col="red")
    hist(Rhat$gamma2$psrf[, 1], main="gamma2", breaks=100)
    abline(v=max(Rhat$gamma2$psrf[, 1]), col="red")
    hist(Rhat$lambda2$psrf[, 1], main="lambda2", breaks=100)
    abline(v=max(Rhat$lambda2$psrf[, 1]), col="red")
    hist(Rhat$tau2$psrf[, 1], main="tau2", breaks=100)
    abline(v=max(Rhat$tau2$psrf[, 1]), col="red")
    hist(Rhat$s2$psrf[, 1], main="s2", breaks=100)
    abline(v=max(Rhat$s2$psrf[, 1]), col="red")
    hist(Rhat$nu$psrf[, 1], main="nu", breaks=100)
    abline(v=max(Rhat$nu$psrf[, 1]), col="red")
    hist(Rhat$v_inv$psrf[, 1], main="v_inv", breaks=100)
    abline(v=max(Rhat$v_inv$psrf[, 1]), col="red")
    
    # if (type == "sim") {
    #   write.csv(Rhat, file="./diagnostics/sim/tppca_lasso_Rhat.csv")
    # } else if (type == "observer") {
    #   write.csv(Rhat, file="./diagnostics/observer/tppca_lasso_Rhat.csv")
    # } else if (type == "outlier-removed") {
    #   write.csv(Rhat, file="./diagnostics/outlier-removed/tppca_lasso_Rhat.csv")
    # } else {
    #   stop("enter a valid type")
    # }
  } else{
    stop("enter a valid model")
  }
}

