##
## Function to construct the principal component rotations for use in pPCA models
##

makePPCA <- function(X, p){ ## X is the pattern matrix, p is the number of columns to keep when truncating
    N <- dim(X)[1]
    d <- dim(X)[2]
    X_center <- matrix(0, N, d)
    m <- colMeans(X)
    for(i in 1:N){
      X_center[i, ] <- X[i, ] - m ## re
    }
    
    ## Esimate loading matrix K_hat
    pc_out <- prcomp(X_center)
    U <- pc_out$rotation
    lambda <- pc_out$sdev^2
    Lambda <- diag(lambda)
    U_p <- U[, 1:p]
    Lambda_p <- diag(lambda[1:p])
    lambda_bar <- sum(lambda[(p+1):d]) /  (d - p)
    I_p <- diag(p)
    
    if(p == d){
      K <- U %*% sqrt(Lambda)
      Lambda_mat <- Lambda
      lambda_vec <- diag(Lambda)
    } else {
      K <- U_p %*% sqrt(Lambda_p - lambda_bar * I_p)
      Lambda_mat <- diag(diag(Lambda_p) - lambda_bar)
      lambda_vec = diag(Lambda_mat)
    }
    return(list(K_hat=K,                                    ## The MLE estimate for the rotation matrix K
                Lambda=Lambda_mat,                          ## The pxp matrix containing the eigenvalues in decresing order scaled according to truncation
                lambda=lambda_vec,                          ## The p vector containing the eigenvalues in decresing order scaled according to truncation
                X_center=X_center                           ## The centered pattern matrix
                ))
  }