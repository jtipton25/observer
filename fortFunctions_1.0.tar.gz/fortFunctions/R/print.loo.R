print.loo <- function(x, ..., digits = 1, warn = TRUE, plot_k = FALSE) {
  lldims <- paste(attr(x, "log_lik_dim"), collapse = " by ")
  cat("Computed from", lldims, "log-likelihood matrix\n\n")
  z <- x[-grep("pointwise|pareto_k", names(x))]
  uz <- unlist(z)
  nms <- names(uz)
  ses <- grepl("se", nms)
  out <- data.frame(Estimate = uz[!ses], SE = uz[ses])
  out <- format(round(out, digits), nsmall = digits)
  print(out, quote = FALSE)
  if ("pareto_k" %in% names(x)) {
    if (warn)
      k_warnings(x$pareto_k, digits)
    if (plot_k)
      plot(x, ...)
  }
  invisible(x)
}

print.compare.loo <- function(x, ..., digits = 1) {
  print(format(round(x, digits), nsmall = digits), quote = FALSE)
}

plot.loo <- function(x, ..., label_points = FALSE) {
  if (!("pareto_k" %in% names(x)))
    stop("No Pareto k values found.", call. = FALSE)
  k <- x$pareto_k
  if (any(!is.finite(k))) {
    warning(signif(100 * mean(!is.finite(k)), 2),
            "% of k estimates are Inf/NA/NaN and not plotted.")
  }
  plot_k(k, ..., label_points = label_points)
}


plot_k <- function(k, ..., label_points = FALSE) {
  inrange <- function(a, rr) a >= rr[1L] & a <= rr[2L]
  yl <- expression(paste("Shape parameter ", italic(k)))
  xl <- expression(paste("Data ", italic(i)))
  plot(k, xlab = xl, ylab = yl, type = "n", bty = "l", yaxt = "n", ...)
  axis(side = 2, las = 1)
  krange <- range(k)
  for (val in c(0, 0.5, 1)) {
    if (inrange(val, krange))
      abline(h = val, col = "#b17e64", lty = 2, lwd = 1)
  }
  hex_clrs <- c("#6497b1", "#005b96", "#03396c")
  brks <- c(-Inf, 0.5, 1)
  clrs <- ifelse(inrange(k, brks[1:2]), hex_clrs[1],
                 ifelse(inrange(k, brks[2:3]), hex_clrs[2L], hex_clrs[3L]))
  if (all(k < 0.5) || !label_points) {
    points(k, col = clrs, pch = 3, cex = .6)
    return(invisible())
  } else {
    points(k[k < 0.5], col = clrs[k < 0.5], pch = 3, cex = .6)
    sel <- !inrange(k, brks[1:2])
    dots <- list(...)
    txt_args <- c(list(x = seq_along(k)[sel], y = k[sel],
                       labels = seq_along(k)[sel]),
                  if (length(dots) > 0) dots)
    if (!("adj" %in% names(txt_args))) txt_args$adj <- 2/3
    if (!("cex" %in% names(txt_args))) txt_args$cex <- 0.75
    if (!("col" %in% names(txt_args))) txt_args$col <- clrs[sel]
    do.call("text", txt_args)
  }
}






.fr <- function(x, digits) format(round(x, digits), nsmall = digits)
.warn <- function(..., call. = FALSE) warning(..., call. = call.)
k_warnings <- function(k, digits = 1) {
  brks <- c(-Inf, 0.5, 1, Inf)
  kcut <- cut(k, breaks = brks)
  count <- table(kcut)
  prop <- prop.table(count)
  if (sum(count[2:3]) == 0) {
    cat("\nAll Pareto k estimates OK (k < 0.5)")
  } else {
    if (count[2] != 0) {
      txt2 <- "%) Pareto k estimates between 0.5 and 1"
      .warn(paste0(count[2], " (", .fr(100 * prop[2], digits), txt2))
    }
    if (count[3] != 0) {
      txt3 <- "%) Pareto k estimates greater than 1"
      .warn(paste0(count[3], " (", .fr(100 * prop[3], digits), txt3))
    }
    .warn("See PSIS-LOO description (?'loo-package') for more information")
  }
  invisible(NULL)
}
