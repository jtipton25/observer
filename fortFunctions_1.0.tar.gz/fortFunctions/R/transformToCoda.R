transformToCoda = function(output){
  require(coda)
  n_chains=length(output)
  helper_function = function(i, output){
    as.mcmc(data.frame(output[[i]]$params))
  }
  mcmc.list(as.mcmc(lapply(1:n_chains, helper_function, output=output)))
}  