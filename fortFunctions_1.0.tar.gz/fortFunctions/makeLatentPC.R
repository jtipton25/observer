m <- 1000 # number of spatial locations
locs <- seq(0, 1, , m) # spatial coordinate
W <- cbind(rep(1, m), locs,
           cos(2 * pi * locs), 
           cos(10 * pi * locs),
           cos(4 * pi * locs),
           sin(2 * pi * locs), 
           sin(10 * pi * locs),
           sin(4 * pi * locs),
           cos(2 * pi * locs) * sin(2 * pi * locs), 
           cos(2 * pi * locs) * sin(10 * pi * locs),
           cos(2 * pi * locs) * sin(4 * pi * locs),
           cos(10 * pi * locs) * sin(2 * pi * locs), 
           cos(10 * pi * locs) * sin(10 * pi * locs), 
           cos(10 * pi * locs) * sin(4 * pi * locs), 
           cos(4 * pi * locs) * sin(2 * pi * locs), 
           cos(4 * pi * locs) * sin(10 * pi * locs), 
           cos(4 * pi * locs) * sin(4 * pi * locs))
reps <- 50 #150 # number of spatial fields
beta <- matrix(c(rnorm(reps, 0, 0.1), rnorm(reps, 2, 0.1), 
                 seq(-0.25, 0.25, length=reps), 
                 rep(seq(-0.25, 0.25, length=5), 10), 
                 rep(seq(-0.25, 0.25, length=25), 2),
                 seq(-0.25, 0.25, length=reps), 
                 rep(seq(-0.25, 0.25, length=5), 10), 
                 rep(seq(-0.25, 0.25, length=25), 2),
               seq(-0.25, 0.25, length=reps), 
               rep(seq(-0.25, 0.25, length=5), 10), 
               rep(seq(-0.25, 0.25, length=25), 2),
               seq(-0.25, 0.25, length=reps), 
               rep(seq(-0.25, 0.25, length=5), 10), 
               rep(seq(-0.25, 0.25, length=25), 2),
               seq(-0.25, 0.25, length=reps), 
               rep(seq(-0.25, 0.25, length=5), 10), 
               rep(seq(-0.25, 0.25, length=25), 2)),
               dim(W)[2], reps,
               byrow = TRUE) # beta

s2_s <- 1
phi <- 0.25
s2_hist <- 0.5
s2_obs <- 0.25
nu <- 10
samp_size <- 5:40


mu <- W %*% beta
Sig_s <- toeplitz(c(1, rep(0.99, m-1)))
# Sig_s <- 2 * exp(-as.matrix(dist(locs)) * phi)
layout(matrix(1:4, 2, 2))

X <- matrix(NA, m, reps)
for(i in 1:reps){
  X[,i ] <- mvrnormArmaVec()
}
matplot(X <-W %*% beta + t(chol(Sig_s)) %*% matrix(rnorm(m*reps), m, reps), type = 'l')
matplot(X_noisy <-X + rnorm(m*reps, 0, 0.1), type = 'l')
matplot(makePCA(X)$X_pca[, 1:5], type = 'l')
matplot(makePCA(X_noisy)$X_pca[, 1:5], type = 'l')
