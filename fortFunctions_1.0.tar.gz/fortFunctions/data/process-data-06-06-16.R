#  Getting settlement climatologies:
#  At this point we have three sources of data:
#  1.  Gridded climate data based on USHCN and other global climate stations
#      that are spatially smoothed.
#  2.  The explicit USHCN data
#  3.  The Historic climate records from US forts.
#
#  I will import each of the station data, then combine them, identifying the
#  station using geographic coordinates, the date (year & month) and then
#  providing a factor level for the data source.  Using these I hope to be able
#  to build a Bayesian model that can generate estimates of climate at a given
#  point x,y (corresponding to the data in the PLSS) for the time period of
#  survey.

#  David Ludlum - cold winters, PDSI
#  Check for rapid changes in weather over 24hrs.
#  

setwd("~/Dropbox/paleonpaleoclimate/data/sjg_code")

library(raster)
library(plyr)
library(ggplot2)
library(mgcv)
library(automap)
library(scales)

# We just use this raster to crop the USHCN records.  I could do it easily with
# an extent.
out.veg <- projectRaster(raster('../../Witness_Trees/WitnessTrees/data/input/rasters/numplots_alb.tif'),
                          crs = '+init=EPSG:4326')

# 
#  Get the USHCN data:
#  This ought to be a fixed width table:
ushcn.metadata <- read.fwf('ushcn-stations.txt', 
                           widths = c(6, 9, 10, 7, 3, 31, 7, 7, 7, 3),
                           stringsAsFactors = FALSE,
                           comment.char = '')

ushcn.climate <- read.fwf('9641C_201112_F52.avg',
                          widths = c(11, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7),
                          stringsAsFactors = FALSE)

#  Let's first get just the july temperatures:
ushcn.climate <- ushcn.climate[,c(1, 8)]

#  Currently, the climate data is clipped, so we're only really interested in 
#  USHCN stations within the clipped domain.  The first six characters of the
#  first column let us know where the point was:
in.domain <- findInterval(ushcn.metadata[,2], bbox(out.veg)[2,]) == 1 &
             findInterval(ushcn.metadata[,3], bbox(out.veg)[1,]) == 1

ushcn.stn <- substr(ushcn.climate[,1], 1,6) %in% ushcn.metadata[in.domain,1]
ushcn.lookup <- substr(ushcn.climate[ushcn.stn,1], 1,6)

ushcn.table <- data.frame(year = as.numeric(substr(ushcn.climate[ushcn.stn,1], 8, 11)),
                          lat  = ushcn.metadata[match(ushcn.lookup, ushcn.metadata[,1]),2],
                          long = ushcn.metadata[match(ushcn.lookup, ushcn.metadata[,1]),3],
                          temp = as.numeric(ushcn.climate[ushcn.stn,2]) / 10,
                          data = 'USHCN',
                          stn  = as.numeric(substr(ushcn.climate[ushcn.stn,1], 1, 7)),
                          class = NA)

################################################################################
#  Forts data:
#  The forts data is going to be tricky.  Some of it is daily min or max, some
#  is hourly, some is other stuff.  To resolve this problem we build a model that
#  accounts for the diurnal cycle.  This is processed in a `bam` below:

fort.files <- list.files('Fort Data/', full.names = TRUE)

fort.clim <- fort.files[regexpr('.data.', fort.files, fixed = TRUE) > 0]
fort.meta <- fort.files[regexpr('.metadata.', fort.files, fixed = TRUE) > 0]

trim.data <- function(x){
  data <- read.csv(x, header = TRUE, stringsAsFactors = FALSE)
  
  temp.cols <- (1:ncol(data))[regexpr('T', colnames(data)) == 1]
  
  out <- data.frame(year  = rep(data$YEAR, length(temp.cols)),
                    day   = rep(data$DAY, length(temp.cols)),
                    month = rep(data$MO, length(temp.cols)),
                    lat   = rep(data$LAT, length(temp.cols)),
                    long  = rep(data$LON, length(temp.cols)),
                    temp  = as.numeric(as.character(unlist(data[,temp.cols]))),
                    data  = 'Forts',
                    stn   = rep(data$STNO, length(temp.cols)),
                    name  = substr(x, regexpr('//', x) + 2, nchar(x) - 9),
                    class = rep(colnames(data)[temp.cols], each = nrow(data)))
  
  out <- out[!is.na(out$temp),]
  out
}

fort.table <- ldply(fort.clim, trim.data, .progress = 'text')
fort.table$class <- as.character(fort.table$class)
fort.table$class <- substr(fort.table$class, 1, 7)

fort.table$hour <- as.numeric(substr(fort.table$class, 6, 7))
fort.table$measure <- substr(fort.table$class, 2, 4)

#  Clear all forts with bad lat/long (n=558)
fort.table <- fort.table[rowSums(fort.table == -999, na.rm = TRUE) == 0,]

#  For some reason some of the records in the Champaign Urbana station are in degrees C:
#  I actually don't think it is.  The commented line was orignially used, 
# but it's unclear which values are in oC and which are in F.  The record is a mess.
# We'll drop it.
fort.table <- fort.table[!fort.table$stn == 111399, ]

#  The records indicate special time codes:
#  Hour 91 - Sunrise (in July between 5:20 - 5:40, but shifts to 4:30 by 1820 because of the institution of DST)
#  Hour 92 - Sunset  (7:50pm in 1880)
#  Hour 93 - Morning (think about assignment, use 9am)
#  Hour 94 - Afternoon (as above, use 3pm)
#  Hour 95 - Evening (as above, use 7pm)
#  Hour 99 - Unknown

fort.table$hour[fort.table$hour == 91] <- 4.5
fort.table$hour[fort.table$hour == 92] <- 19.6
fort.table$hour[fort.table$hour == 93] <- 8
fort.table$hour[fort.table$hour == 94] <- 15
fort.table$hour[fort.table$hour == 95] <- 18

# This is based on assessment of hourly records from the region:
fort.table$hour[regexpr('MAX', fort.table$class) > 0] <- 15
fort.table$hour[regexpr('MIN', fort.table$class) > 0] <- 6

# Assign a compound, decimal julian period:
fort.table$ymdh <- fort.table$year + (fort.table$month + (fort.table$day + fort.table$hour/24)/31)/12

stn_plot <- function(x, thing='temp', path=''){
  stn_rec <- subset(fort.table, stn == x)
  
  ggsave(plot = ggplot(stn_rec, aes(x = ymdh, y = eval(thing))) + geom_line() + ggtitle(x), 
          filename = paste0('~/spatialModeling/fortData/StnFigs/',path, x, '_',thing, '.png'))
}

#  Now get rid of all the 99s, and all MIN/MAX values, they're weird..
fort.table <- fort.table[fort.table$hour < 25, ]

#  this still leaves us with 94471 unique entries.
fort.table$stn <- factor(fort.table$stn)

#####################################################################
#  This code can't be run except by me, on my lab computer, but it will spit
#  out a dataframe similar to the fort.table file.
#  Columns are:
#  Site name
#  State
#  Long
#  Lat
#  Stn #
#  Date (in yyy-mm-dd format)
#  Tmax
#  Tmin
#  Precip
#  Snowfall
#  Snowdepth
# 
# full.files <- list.files(path='../../../Paleoclimate_storage/Data_1890_1905/',
#                           full.names=TRUE)
# 
# state <- sapply(full.files, function(x){scan(x, what = 'character', sep=',', nlines = 1, strip.white = TRUE)[2]})
# good.sites <- state %in% c("MN", "WI", "IA", "IL", "MI")
# 
# samples <- full.files[good.sites]
# 
# 
# for(i in 1:length(samples)){
#   site <- read.csv(samples[i], strip.white = TRUE, header = FALSE)
#   
#   site.df <- data.frame(year = substr(site[,6], 1, 4),
#                         month = substr(site[,6], 6, 7),
#                         day = substr(site[,6], 9, 10),
#                         long = site[,2], lat = site[,3],
#                         data = 'Gap',
#                         site = site[,1], state = site[,2],
#                         tmax = site[,7], tmin = site[,8],
#                         precip = site[,9],
#                         snowfall = site[,10], snowdepth = site[,11])
#   
#   if(i == 1){
#     fort_interval <- site.df
#   }
#   if(i > 1){
#     fort_interval <- rbind(fort_interval, site.df)
#   }
#                         
# }
#  The code has been run once, it looks good:
#
##############################################################

interval <- read.csv('fort_interval.csv')[,-1]
colnames(interval)[9] <- 'name'

# There are 748 Stations, with 20 stations that overlap between the two records.
interval <- subset(interval, !(lat == 0 | long == 0))

fort.table <- rbind(fort.table, interval)

fort.table$stn <- as.character(fort.table$stn)

# Now lets do the Visual estimate again:
# lapply(unique(fort.table$stn), stn_plot)


#######################
#  Now build a model of hourly temperatures using modern data:
#  

july.table <- subset(fort.table, month == 7)
july.table$stn <- factor(july.table$stn)

# This is just so big!  450205 individual records:
# This runs, it takes a while, and the "summary" seems to take forever as well.
#  There is an apparent effect of latitude in the daily model (we can see it in the
#  julyplot figure), so we want to account for that.
model <- bam(temp ~ s(hour, bs = 'cc', k = 5) + s(stn, bs = 're') + lat + year, 
                method = "REML",
                data = july.table)

model_yr <- bam(temp ~ s(hour, bs = 'cc', k = 5) + s(stn, year, bs = 're') + lat, 
             method = "REML",
             data = july.table)

# Note, that with the model as:
# model <- bam(temp ~ s(hour, bs='cc', k=4) + s(stn, bs='re'), 
#              data = july.table)
#  We get a range of daily temperatures for samples that are taken in the same day.
#  Basically, it doesn't seem to detrend things.  This may be, in part, because the timing
#  of measurement varies by latitude.  More a function of a change in when samples were taken
#  during the "filling in" of temperature measurements.
#
#  With this data cleaning we can explain 69.6% of the total variance.  It gives
#  us a mean diurnal cycle across each station.  It would be interesting to see if
#  there is any sort of spatial pattern, but for now, I'm going to sort of 
#  ignore those questions.

july.table$cleaned <- 
  predict(model, newdata = data.frame(stn  = july.table$stn,
                                      hour = 8.5,
                                      year = july.table$year,
                                      lat  = july.table$lat), 
          type = 'response')

july.table$year_re <- 
  predict(model_yr, newdata = data.frame(stn  = july.table$stn,
                                         hour = 8.5,
                                         year = july.table$year,
                                         lat  = july.table$lat), 
          type = 'response') + resid(model_yr, type = 'response')


stn_plot <- function(x){
  
  # A ggplot for each station, faceted by year.
  
  stn_rec <- subset(july.table, stn == x)
  
  ggsave(plot = ggplot(stn_rec, aes(x = day, y = cleaned)) + 
           geom_line() + 
           geom_line(aes(x = day, y = temp), color = 'blue', alpha = 0.5) +
           geom_line(aes(x = day + 0.25, y = year_re), color = 'red', alpha = 0.5) +
           ggtitle(x) + 
           facet_wrap(~year) + 
           theme_bw(), 
         filename = paste0('~/spatialModeling/fortData/StnFigs/july/', x, '.png'),
         dpi = 96, width = 6, height = 6)
}

year_plot <- function(x){
  
  # A plot for each year, faceted by station:
  
  stn_rec <- subset(july.table, year == x)
  
  ggsave(plot = ggplot(stn_rec, aes(x = day, y = cleaned)) + 
           geom_line() + 
           geom_line(aes(x = day, y = temp), color = 'blue', alpha = 0.5) +
           geom_line(aes(x = day + 0.25, y = year_re), color = 'red', alpha = 0.5) +
           ggtitle(x) + 
           facet_wrap(~stn) + 
           theme_bw(), 
         filename = paste0('~/spatialModeling/fortData/StnFigs/july/years/', x, '.png'))
}

# Screen by station & by year:
lapply(unique(july.table$stn), stn_plot)
lapply(unique(july.table$year), year_plot)

# This is a big cluster plot for the hourly temperature curve:

july_plot <- ggplot(aes(x = hour, y = temp), data = july.table) +
  geom_jitter(alpha = 0.2, aes(color = lat)) +
  geom_smooth(method = 'gam', 
              formula = y ~ s(x, bs = 'cc', k = 4), 
              se = TRUE, 
              size = 3, 
              color = "#FF9999") +
  xlab('Hour of the Day') +
  ylab('Temperature, degrees F') +
  theme_bw() +
  theme(axis.text = element_text(size = 14, family = 'serif'),
        axis.title = element_text(size = 24, family = 'serif', face = 'bold'),
        strip.text = element_text(size = 24, family = 'serif', face = 'bold'),
        rect = element_rect(color = 'white'),
        legend.text = element_text(size = 14, family = 'serif'))

ggsave(july_plot, filename = "~/spatialModeling/fortData/figures/july_prescreen.tiff", dpi = 300, width = 6, height = 6)

#  So this is the annual aggregate, with an sd for the month, and the number of records in the month.
#
#  First, convert to Celcius:
july.table$year_re <- (july.table$year_re - 32) / 9 * 5

avg.ann <- with(july.table, 
                aggregate(year_re, by = list(year = year, stn = stn), mean, na.rm = TRUE))

sd.ann <-  with(july.table, 
                aggregate(year_re, by = list(year = year, stn = stn), sd, na.rm = TRUE))

len.ann <-  with(july.table, 
                aggregate(year_re, by = list(year = year, stn = stn), length))

avg.big <- data.frame(year = c(avg.ann[,1], ushcn.table$year),
                      temp = c(avg.ann$x, (ushcn.table$temp - 32)/9 * 5))

#  This is an estimate of the mean site level anomaly
ggplot(data = avg.big) + 
  geom_jitter(aes(x = year, y = temp), alpha = 0.5) + 
  geom_smooth(method = 'gam', formula = y ~ s(x, k = 100), aes(x = year, y = temp),
              size = 2, color = 'red') +
  theme_bw() + xlab('Calendar Year') + ylab('Temperature (C)') +
  theme(axis.title.x = element_text(family = 'serif', face = 4, size = 24),
        axis.title.y = element_text(family = 'serif', face = 4, size = 24),
        axis.text.x = element_text(family  = 'serif', face = 2, size = 18),
        axis.text.y = element_text(family  = 'serif', face = 2, size = 18))

################################################################################
#  Spatial interpolation:
#  So we have the aggregated annual July temperature, and the station numbers.  
#  Let's match those now and output everything:

stn.agg <- data.frame(year = avg.ann$year,
                      stn  = avg.ann$stn,
                      lat  = fort.table$lat[match(avg.ann$stn, fort.table$stn)],
                      long = fort.table$long[match(avg.ann$stn, fort.table$stn)],
                      temp = avg.ann$x,
                      sd   = sd.ann$x,
                      n    = len.ann$x)

write.csv(july.table, '~/spatialModeling/data/fort_july_full.csv')
write.csv(stn.table, '~/spatialModeling/data/fort_july_agg.csv')

stn.agg <- rbind(stn.agg, with(ushcn.table, 
                               data.frame(year = year, 
                                          stn  = stn, 
                                          lat  = lat, 
                                          long = -long, 
                                          temp = (temp - 32) / 9 * 5,
                                          sd   = NA,
                                          n    = NA)))

write.csv(stn.agg, '~/spatialModeling/data/all_july_agg.csv')
