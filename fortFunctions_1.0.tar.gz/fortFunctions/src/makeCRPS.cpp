#include <RcppArmadillo.h>

// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::interfaces(r, cpp)]]

using namespace Rcpp;
using namespace arma;

//[[Rcpp::export]]
arma::mat makeCRPS(const NumericVector& myArray, const arma::mat& truth,
                   const int& n_samps){
  NumericVector vecArray(myArray);
  IntegerVector arrayDims = vecArray.attr("dim");
  cube estimate(vecArray.begin(), arrayDims(0), arrayDims(1), arrayDims(2));
  int N = truth.n_rows;
  int t = truth.n_cols;
  arma::mat CRPS(N, t, fill::zeros);
  for(int i=0; i<t; i++){
    // Rcout << " " << i + 1;
    double accuracy = 0.0;
    double precision = 0.0;
    for(int j=0; j<N; j++){
      for(int k=0; k<n_samps; k++){
        Rcpp::checkUserInterrupt();
          accuracy += std::abs(estimate(k, j, i) - truth(j, i));
        for(int l=0; l<n_samps; l++){
          precision += std::abs(estimate(k, j, i) - estimate(l, j, i));
        }
      }
      CRPS(j, i) = 1.0 / n_samps * accuracy - 0.5 / pow(n_samps, 2) * precision;
    }
  }
  return(CRPS);
}

