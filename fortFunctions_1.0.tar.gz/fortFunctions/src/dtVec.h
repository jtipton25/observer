#include <RcppArmadillo.h>

// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::interfaces(cpp)]]

using namespace Rcpp;
using namespace arma;

vec dtVec(const vec& y, const vec& mu, const double& nu, const double& s){
  int size = y.n_elem;
  vec out(size, fill::zeros);
  for(int i=0; i<size; i++){
    out(i) = R::dt((y(i) - mu(i)) / s, nu, 1);
  }
  return(out);
}
