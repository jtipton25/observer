#include <RcppArmadillo.h>

// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::interfaces(cpp)]]

using namespace Rcpp;
using namespace arma;

vec dnormVec(const vec& y, const vec& mu, const double& s){
  int size = y.n_elem;
  vec out(size, fill::zeros);
  for(int i=0; i<size; i++){
    out(i) = R::dnorm(y(i), mu(i), s, 1);
  }
  return(out);
}
