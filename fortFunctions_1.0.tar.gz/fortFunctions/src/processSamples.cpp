#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]
#include "dnormVec.h"
// [[Rcpp::interfaces(r)]]

using namespace Rcpp;
using namespace arma;

// vec dnormVec(const vec& y, const vec& mu, const double& s){
//   int size = y.n_elem;
//   vec out(size, fill::zeros);
//   for(int i=0; i<size; i++){
//     out(i) = R::dnorm(y(i), mu(i), s, 1);
//   }
//   return(out);
// }

// [[Rcpp::export]]
Rcpp::List processSamples(const int& t, const int& p, const int& n_samps, 
                          const int& N, const NumericVector& myArray, 
                          const arma::mat& tau2s, const arma::vec& s2s, 
                          const Rcpp::List& Y, const Rcpp::List& H, 
                          const arma::vec& n_obs, const arma::mat& X,
                          const arma::mat& tKK, const arma::mat& I_p,
                          const arma::mat& K_hat, const arma::vec& mu,
                          const int& n_thin, const bool& preds=true, 
                          const bool& quantiles=false){
  Environment stats("package:stats");
  Function quantile = stats["quantile"];
  NumericVector vecArray(myArray);
  IntegerVector arrayDims = vecArray.attr("dim");
  cube betas(vecArray.begin(), arrayDims(0), arrayDims(1), arrayDims(2));
  if(preds){
    arma::cube y_tilde(n_samps / n_thin, N, t);
    Rcpp::List log_like(t);
    arma::mat y_tilde_mean(N, t);
    arma::mat y_tilde_sd(N, t);
    arma::mat y_tilde_25(N, t);
    arma::mat y_tilde_975(N, t);
    arma::mat X_K_hat = X * K_hat;
    Rcpp::List H_list(t);
    for(int i=0; i<t; i++){
      vec H_vec = H(i);
      H_vec -= 1;
      H_list(i) = H_vec;
    }  
    for(int i=0; i<t; i++){
      // Rcout << "Year " << i + 1 << "\n";
      arma::mat yearly_samples(n_samps / n_thin, N);
      arma::mat yearly_like(n_samps / n_thin, n_obs(i));
      arma::vec Y_vec = Y(i);
      arma::vec Y_center = Y_vec - mu(i);
      uvec Hidx = H_list(i);
      for(int j=0; j<n_samps; j++){
        if(j % n_thin == 0){
          Rcpp::checkUserInterrupt();
          arma::mat M_inv = inv_sympd(1.0 / s2s(j) * tKK + I_p);
          arma::vec beta_vec(p);
          for(int l=0; l<p; l++){
            beta_vec(l) = betas(j, i, l);
          }
          arma::vec mu_y = 1.0 / s2s(j) * X_K_hat * M_inv * beta_vec;
          double s_y = sqrt(as_scalar(tau2s(j, i) + 
                              beta_vec.t() * M_inv * beta_vec));
          for(int k=0; k<N; k++){
            yearly_samples(j / n_thin, k) = R::rnorm(mu_y(k), s_y) + mu(i);
          }
          yearly_like.row(j / n_thin) = dnormVec(Y_center, mu_y.rows(Hidx), s_y).t();
        }
      }
      for(int k=0; k<N; k++){
        vec samples = yearly_samples.col(k);
        y_tilde_mean(k, i) = arma::mean(samples);
        y_tilde_sd(k, i) = arma::stddev(samples);
        if(quantiles){
          y_tilde_25(k, i) = as<double>(quantile(samples, 0.025));
          y_tilde_975(k, i) = as<double>(quantile(samples, 0.975));
        }
      }
      y_tilde.slice(i) = yearly_samples;
      log_like(i) = yearly_like;
    }
    if(quantiles){
      return(Rcpp::List::create(
          _["y_tilde"] = y_tilde,
          _["log_like"] = log_like,
          _["y_tilde_mean"] = y_tilde_mean,
          _["y_tilde_sd"] = y_tilde_sd,
          _["y_tilde_25"] = y_tilde_25,
          _["y_tilde_975"] = y_tilde_975));
    } else {
      return(Rcpp::List::create(
          _["y_tilde"] = y_tilde,
          _["log_like"] = log_like,
          _["y_tilde_mean"] = y_tilde_mean,
          _["y_tilde_sd"] = y_tilde_sd));
    }
  } else { // No posterior predcitions
    Rcpp::List log_like(t);
    arma::mat y_tilde_mean(N, t);
    arma::mat y_tilde_sd(N, t);
    arma::mat y_tilde_25(N, t);
    arma::mat y_tilde_975(N, t);
    arma::mat X_K_hat = X * K_hat;
    Rcpp::List H_list(t);
    for(int i=0; i<t; i++){
      vec H_vec = H(i);
      H_vec -= 1;
      H_list(i) = H_vec;
    }  
    for(int i=0; i<t; i++){
      // Rcout << "Year " << i + 1 << "\n";
      arma::mat yearly_samples(n_samps / n_thin, N);
      arma::mat yearly_like(n_samps / n_thin, n_obs(i));
      arma::vec Y_vec = Y(i);
      arma::vec Y_center = Y_vec - mu(i);
      uvec Hidx = H_list(i);
      for(int j=0; j<n_samps; j++){
        if(j % n_thin == 0){
          Rcpp::checkUserInterrupt();
          arma::mat M_inv = inv_sympd(1.0 / s2s(j) * tKK + I_p);
          arma::vec beta_vec(p);
          for(int l=0; l<p; l++){
            beta_vec(l) = betas(j, i, l);
          }
          arma::vec mu_y = 1.0 / s2s(j) * X_K_hat * M_inv * beta_vec;
          double tau_y = sqrt(as_scalar(tau2s(j, i) + 
                              beta_vec.t() * M_inv * beta_vec));
          for(int k=0; k<N; k++){
            yearly_samples(j / n_thin, k) = R::rnorm(mu_y(k), tau_y) + mu(i);
          }  
          yearly_like.row(j / n_thin) = dnormVec(Y_center, mu_y.rows(Hidx), tau_y).t();
        }
      } 
      for(int k=0; k<N; k++){
        vec samples = yearly_samples.col(k);
        y_tilde_mean(k, i) = arma::mean(samples);
        y_tilde_sd(k, i) = arma::stddev(samples);
        if(quantiles){
          y_tilde_25(k, i) = as<double>(quantile(samples, 0.025));
          y_tilde_975(k, i) = as<double>(quantile(samples, 0.975));
        }
      }
      log_like(i) = yearly_like;
    }
    if(quantiles){
      return(Rcpp::List::create(
        _["log_like"] = log_like,
        _["y_tilde_mean"] = y_tilde_mean,
        _["y_tilde_sd"] = y_tilde_sd,
        _["y_tilde_25"] = y_tilde_25,
        _["y_tilde_975"] = y_tilde_975));
    } else {
      return(Rcpp::List::create(
        _["log_like"] = log_like,
        _["y_tilde_mean"] = y_tilde_mean,
        _["y_tilde_sd"] = y_tilde_sd));
    }
  }
}
